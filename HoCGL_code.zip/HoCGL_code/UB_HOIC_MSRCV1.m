clear all;
tic;


load("MSRCV1_0.5_Ubalaced_incomplete.mat");
lambda1 = 0.05;
lambda2 = 0.5;
lambda3 = 0.1;
order = 5;

result1 = HoCGL(X,lambda1,lambda2,lambda3,order,W,gt);
fprintf("AC = %5.4f，NMI = %5.4f，purity = %5.4f\n",result1(1),result1(2),result1(3));

