function [result]=HoCGL(X,lambda1,lambda2,lambda3,order,W,gt)
fprintf("HCGL:");
epson = 1e-7;
C = size(unique(gt),1); % number of clusters
V = size(X,2); % number of views
N = size(X{1},2);% number of data points

% %normalized X
for i=1:V
    X{i} = NormalizeFea(X{i},0);  %Normalize feature
end
%Initilize Z,B,E,multiplier Y,Y2
for i = 1:V
    Z{i} = zeros(N,N);
    B{i} = zeros(size(X{i},1),N);
    E{i} = zeros(size(X{i},1),size(W{i},1));
    G{i} = zeros(N,N);
    Y{i} = zeros(size(X{i},1),N); %multiplier
    Y2{i} = zeros(N,N);  %multiplier
    Z_star = zeros(N,N);
end

weight = 1/V*ones(1,V);  % 初始化自适应权重

mu = 0.1; %mu is designed to speed up
mu_max = 1e10;
eta = 2;
converge_Z=[]; converge_Z_G=[];

Isconverg = 0;
iter = 1;
%%  iteration


for v = 1:V
    Sn{v}=high_order_graph(X{v}',order);
end
while(Isconverg == 0)

    % == update B{i} ==
    for i=1:V
        F1 = (X{i}+E{i}*W{i})-(X{i}+E{i}*W{i})*Z{i}+Y{i}./mu;
        B{i} = solve_l1l2(F1,lambda2./mu);
    end

    % == update Z{i} ==
    for i = 1:V
        H = X{i}+E{i}*W{i};
        A2 = H-B{i}+Y{i}./mu;
        A3 = G{i}-Y2{i}./mu;
        Z1 = 2*lambda3*eye(N,N)+2*weight(1,i)*eye(N,N)+mu*H'*H+mu*eye(N,N);
        sn_sum = zeros(N,N);
        for j = 1:order
            sn_sum = sn_sum + Sn{i}{j};
        end
        Z2 = 2*lambda3*sn_sum + 2*weight(1,i)*Z_star+mu*H'*A2+mu*A3;
        Z3 = Z1\Z2;


        Z0 = zeros(size(Z3));
        for is = 1:size(Z3,1)
            ind_c = 1:size(Z3,1);
            ind_c(is) = [];
            Z0(is,ind_c) = EProjSimplex_new(Z3(is,ind_c));
        end
        Z{i} = Z0;
    end

    % == update E{i} ==
    for i=1:V
        C_1 = X{i}*Z{i}-X{i}+B{i}-Y{i}./mu;
        D_1 = W{i}-W{i}*Z{i};
        E{i}= mu*C_1*D_1'*(inv(mu*D_1*D_1'));
    end

    % == update G{i} ==

    for i=1:V
        [U1,S1,V1] = svd(Z{i}+Y2{i}./mu);
        a1 = diag(S1)-lambda1/mu;
        a1(a1<0)=0;
        T1 = diag(a1);
        G{i} = U1*T1*V1';
    end

    %% update Z_star
    theta_zv_sum = zeros(N,N);
    theta_sum = zeros(N,N);
    for i=1:V
        theta_zv_sum = theta_zv_sum + weight(1,i)*Z{i};
        theta_sum = theta_sum +  weight(1,i);
    end
    Z_star = theta_zv_sum./theta_sum;


    % update weight
    for i = 1:V
        weight(1,i) = 0.5/norm(Z{i}-Z_star,'fro');
    end

    % == update Y{i} ==
    for i=1:V
        H1 =  X{i}+E{i}*W{i};
        Y{i} = Y{i} + mu*(H1-H1*Z{i}-B{i});
    end
    % == update Y2{i} ==
    for i=1:V
        Y2{i} = Y2{i}+mu*(Z{i}-G{i});
    end


    max_Z=0;
    max_Z_G=0;
    Isconverg = 1;
    for k = 1:V
        H2 = X{k}+E{k}*W{k};

        if (norm(H2- H2*Z{k}-B{k}, inf) > epson)
            history.norm_Z = norm(H2- H2*Z{k}-B{k}, inf);
            Isconverg = 0;
            max_Z = max(max_Z, history.norm_Z);

        end

        if (norm(Z{k} - G{k}, inf) > epson)
            history.norm_Z_G = norm(Z{k} - G{k}, inf);
            Isconverg = 0;
            max_Z_G = max(max_Z_G, history.norm_Z_G);
        end

    end
    converge_Z=[converge_Z max_Z];
    converge_Z_G=[converge_Z_G max_Z_G];


    % == update mu  mu ==
    mu = min(mu_max,mu*eta);
    %fprintf("%d\n",iter);
    if (iter==100)
        Isconverg = 1;
    end
    iter = iter + 1;
end

aff = 0.5*(abs(Z_star)+abs(Z_star'));
Clus = Ng_SpectralClustering(aff,C); %
result = EvaluationMetrics(gt,Clus);

